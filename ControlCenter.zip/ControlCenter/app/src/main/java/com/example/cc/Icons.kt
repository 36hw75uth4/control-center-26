package com.example.cc

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.Shader
import android.graphics.ColorFilter
import android.graphics.drawable.Drawable
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ScrollView

enum class Ic {
    WIFI, BT, AIRPLANE, DATA, TORCH, CAMERA, ALARM, GEAR, MOON, ROTATE,
    BATTERY, SUN, VOLUME, PREV, PLAY, PAUSE, NEXT, CALC, TIMER,
    PLUS, CHECK, MIRROR, QR, QSHARE, HOTSPOT, NFC, AIRDROP
}

/** iOS-style icons drawn with Canvas in a 0..1 unit box. */
object IconPainter {
    fun draw(c: Canvas, ic: Ic, p: Paint, color: Int) {
        p.color = color
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        fun stroke(w: Float) { p.style = Paint.Style.STROKE; p.strokeWidth = w }
        fun fill() { p.style = Paint.Style.FILL }
        fun poly(vararg v: Float) {
            val path = Path()
            path.moveTo(v[0], v[1])
            var i = 2
            while (i < v.size) { path.lineTo(v[i], v[i + 1]); i += 2 }
            path.close()
            c.drawPath(path, p)
        }
        when (ic) {
            Ic.WIFI -> {
                stroke(0.09f)
                for (r in floatArrayOf(0.66f, 0.43f, 0.21f)) {
                    c.drawArc(RectF(0.5f - r, 0.84f - r, 0.5f + r, 0.84f + r), 225f, 90f, false, p)
                }
                fill()
                c.drawCircle(0.5f, 0.84f, 0.065f, p)
            }
            Ic.BT -> {
                stroke(0.09f)
                val path = Path()
                path.moveTo(0.22f, 0.30f)
                path.lineTo(0.74f, 0.70f)
                path.lineTo(0.5f, 0.92f)
                path.lineTo(0.5f, 0.08f)
                path.lineTo(0.74f, 0.30f)
                path.lineTo(0.22f, 0.70f)
                c.drawPath(path, p)
            }
            Ic.AIRPLANE -> {
                fill()
                c.save()
                c.rotate(90f, 0.5f, 0.5f)
                c.scale(1f / 24f, 1f / 24f)
                val path = Path()
                path.moveTo(21f, 16f); path.lineTo(21f, 14f); path.lineTo(13f, 9f); path.lineTo(13f, 3.5f)
                path.cubicTo(13f, 2.67f, 12.33f, 2f, 11.5f, 2f)
                path.cubicTo(10.67f, 2f, 10f, 2.67f, 10f, 3.5f)
                path.lineTo(10f, 9f); path.lineTo(2f, 14f); path.lineTo(2f, 16f); path.lineTo(10f, 13.5f)
                path.lineTo(10f, 19f); path.lineTo(8f, 20.5f); path.lineTo(8f, 22f); path.lineTo(11.5f, 21f)
                path.lineTo(15f, 22f); path.lineTo(15f, 20.5f); path.lineTo(13f, 19f); path.lineTo(13f, 13.5f)
                path.close()
                c.drawPath(path, p)
                c.restore()
            }
            Ic.DATA -> {
                fill()
                for (i in 0..3) {
                    val l = 0.1f + i * 0.22f
                    val h = 0.25f + i * 0.18f
                    c.drawRoundRect(RectF(l, 0.9f - h, l + 0.14f, 0.9f), 0.04f, 0.04f, p)
                }
            }
            Ic.TORCH -> {
                fill()
                val path = Path()
                path.fillType = Path.FillType.EVEN_ODD
                path.moveTo(0.27f, 0.06f); path.lineTo(0.73f, 0.06f); path.lineTo(0.73f, 0.2f)
                path.lineTo(0.62f, 0.34f); path.lineTo(0.62f, 0.94f); path.lineTo(0.38f, 0.94f)
                path.lineTo(0.38f, 0.34f); path.lineTo(0.27f, 0.2f); path.close()
                path.addCircle(0.5f, 0.55f, 0.05f, Path.Direction.CW)
                c.drawPath(path, p)
            }
            Ic.CAMERA -> {
                fill()
                val path = Path()
                path.fillType = Path.FillType.EVEN_ODD
                path.addRoundRect(RectF(0.05f, 0.26f, 0.95f, 0.84f), 0.12f, 0.12f, Path.Direction.CW)
                path.addCircle(0.5f, 0.55f, 0.18f, Path.Direction.CW)
                c.drawPath(path, p)
                c.drawRoundRect(RectF(0.3f, 0.14f, 0.7f, 0.3f), 0.05f, 0.05f, p)
            }
            Ic.ALARM -> {
                stroke(0.08f)
                c.drawCircle(0.5f, 0.56f, 0.33f, p)
                c.drawLine(0.5f, 0.56f, 0.5f, 0.38f, p)
                c.drawLine(0.5f, 0.56f, 0.64f, 0.64f, p)
                fill()
                c.drawCircle(0.16f, 0.2f, 0.1f, p)
                c.drawCircle(0.84f, 0.2f, 0.1f, p)
            }
            Ic.GEAR -> {
                stroke(0.11f)
                c.drawCircle(0.5f, 0.5f, 0.24f, p)
                fill()
                for (i in 0..7) {
                    c.save()
                    c.rotate(i * 45f, 0.5f, 0.5f)
                    c.drawRoundRect(RectF(0.43f, 0.06f, 0.57f, 0.24f), 0.03f, 0.03f, p)
                    c.restore()
                }
            }
            Ic.MOON -> {
                fill()
                c.save()
                c.scale(0.01f, 0.01f)
                val a = Path()
                a.addCircle(50f, 50f, 40f, Path.Direction.CW)
                val b = Path()
                b.addCircle(72f, 34f, 34f, Path.Direction.CW)
                a.op(b, Path.Op.DIFFERENCE)
                c.drawPath(a, p)
                c.restore()
            }
            Ic.ROTATE -> {
                stroke(0.085f)
                c.drawArc(RectF(0.12f, 0.12f, 0.88f, 0.88f), 300f, 280f, false, p)
                fill()
                poly(0.286f, 0.164f, 0.286f, 0.320f, 0.132f, 0.192f)
                c.drawRoundRect(RectF(0.4f, 0.48f, 0.6f, 0.66f), 0.03f, 0.03f, p)
                stroke(0.05f)
                c.drawArc(RectF(0.43f, 0.36f, 0.57f, 0.54f), 180f, 180f, false, p)
            }
            Ic.BATTERY -> {
                stroke(0.07f)
                c.drawRoundRect(RectF(0.06f, 0.28f, 0.82f, 0.72f), 0.1f, 0.1f, p)
                fill()
                c.drawRoundRect(RectF(0.86f, 0.43f, 0.95f, 0.57f), 0.03f, 0.03f, p)
                c.drawRoundRect(RectF(0.15f, 0.37f, 0.55f, 0.63f), 0.05f, 0.05f, p)
            }
            Ic.SUN -> {
                fill()
                c.drawCircle(0.5f, 0.5f, 0.17f, p)
                stroke(0.07f)
                for (i in 0..7) {
                    c.save()
                    c.rotate(i * 45f, 0.5f, 0.5f)
                    c.drawLine(0.5f, 0.08f, 0.5f, 0.2f, p)
                    c.restore()
                }
            }
            Ic.VOLUME -> {
                fill()
                poly(0.1f, 0.38f, 0.28f, 0.38f, 0.5f, 0.18f, 0.5f, 0.82f, 0.28f, 0.62f, 0.1f, 0.62f)
                stroke(0.07f)
                c.drawArc(RectF(0.38f, 0.3f, 0.78f, 0.7f), -45f, 90f, false, p)
                c.drawArc(RectF(0.24f, 0.16f, 0.92f, 0.84f), -45f, 90f, false, p)
            }
            Ic.CALC -> {
                stroke(0.07f)
                c.drawRoundRect(RectF(0.17f, 0.06f, 0.83f, 0.94f), 0.1f, 0.1f, p)
                fill()
                c.drawRoundRect(RectF(0.27f, 0.17f, 0.73f, 0.33f), 0.03f, 0.03f, p)
                for (row in 0..2) for (col in 0..2) {
                    c.drawCircle(0.32f + col * 0.18f, 0.5f + row * 0.16f, 0.045f, p)
                }
            }
            Ic.TIMER -> {
                stroke(0.08f)
                c.drawCircle(0.5f, 0.57f, 0.33f, p)
                c.drawLine(0.42f, 0.07f, 0.58f, 0.07f, p)
                c.drawLine(0.5f, 0.07f, 0.5f, 0.24f, p)
                c.drawLine(0.5f, 0.57f, 0.64f, 0.43f, p)
            }
            Ic.PLUS -> {
                stroke(0.1f)
                c.drawLine(0.5f, 0.12f, 0.5f, 0.88f, p)
                c.drawLine(0.12f, 0.5f, 0.88f, 0.5f, p)
            }
            Ic.CHECK -> {
                stroke(0.11f)
                val path = Path()
                path.moveTo(0.14f, 0.55f)
                path.lineTo(0.4f, 0.8f)
                path.lineTo(0.88f, 0.22f)
                c.drawPath(path, p)
            }
            Ic.MIRROR -> {
                stroke(0.07f)
                val path = Path()
                path.moveTo(0.3f, 0.38f)
                path.lineTo(0.3f, 0.1f)
                path.lineTo(0.9f, 0.1f)
                path.lineTo(0.9f, 0.62f)
                path.lineTo(0.7f, 0.62f)
                c.drawPath(path, p)
                c.drawRoundRect(RectF(0.1f, 0.38f, 0.7f, 0.9f), 0.08f, 0.08f, p)
            }
            Ic.QR -> {
                stroke(0.07f)
                val path = Path()
                path.moveTo(0.1f, 0.32f); path.lineTo(0.1f, 0.1f); path.lineTo(0.32f, 0.1f)
                path.moveTo(0.68f, 0.1f); path.lineTo(0.9f, 0.1f); path.lineTo(0.9f, 0.32f)
                path.moveTo(0.1f, 0.68f); path.lineTo(0.1f, 0.9f); path.lineTo(0.32f, 0.9f)
                path.moveTo(0.68f, 0.9f); path.lineTo(0.9f, 0.9f); path.lineTo(0.9f, 0.68f)
                c.drawPath(path, p)
                fill()
                c.drawRoundRect(RectF(0.3f, 0.3f, 0.46f, 0.46f), 0.03f, 0.03f, p)
                c.drawRoundRect(RectF(0.54f, 0.3f, 0.7f, 0.46f), 0.03f, 0.03f, p)
                c.drawRoundRect(RectF(0.3f, 0.54f, 0.46f, 0.7f), 0.03f, 0.03f, p)
                c.drawRoundRect(RectF(0.56f, 0.56f, 0.7f, 0.7f), 0.03f, 0.03f, p)
            }
            Ic.QSHARE -> {
                stroke(0.09f)
                c.drawLine(0.12f, 0.33f, 0.86f, 0.33f, p)
                c.drawLine(0.86f, 0.33f, 0.66f, 0.13f, p)
                c.drawLine(0.86f, 0.33f, 0.66f, 0.53f, p)
                c.drawLine(0.88f, 0.67f, 0.14f, 0.67f, p)
                c.drawLine(0.14f, 0.67f, 0.34f, 0.47f, p)
                c.drawLine(0.14f, 0.67f, 0.34f, 0.87f, p)
            }
            Ic.HOTSPOT -> {
                fill()
                c.drawCircle(0.5f, 0.5f, 0.09f, p)
                stroke(0.08f)
                for (r in floatArrayOf(0.24f, 0.4f)) {
                    val rect = RectF(0.5f - r, 0.5f - r, 0.5f + r, 0.5f + r)
                    c.drawArc(rect, 135f, 90f, false, p)
                    c.drawArc(rect, -45f, 90f, false, p)
                }
            }
            Ic.NFC -> {
                stroke(0.07f)
                c.drawRoundRect(RectF(0.1f, 0.1f, 0.9f, 0.9f), 0.18f, 0.18f, p)
                val path = Path()
                path.moveTo(0.32f, 0.7f)
                path.lineTo(0.32f, 0.3f)
                path.lineTo(0.68f, 0.7f)
                path.lineTo(0.68f, 0.3f)
                c.drawPath(path, p)
            }
            Ic.AIRDROP -> {
                fill()
                c.drawCircle(0.5f, 0.5f, 0.075f, p)
                stroke(0.085f)
                for (r in floatArrayOf(0.22f, 0.4f)) {
                    c.drawArc(RectF(0.5f - r, 0.5f - r, 0.5f + r, 0.5f + r), 125f, 290f, false, p)
                }
            }
            Ic.PREV -> {
                fill()
                poly(0.92f, 0.2f, 0.92f, 0.8f, 0.5f, 0.5f)
                poly(0.5f, 0.2f, 0.5f, 0.8f, 0.08f, 0.5f)
            }
            Ic.PLAY -> {
                fill()
                poly(0.25f, 0.12f, 0.25f, 0.88f, 0.85f, 0.5f)
            }
            Ic.PAUSE -> {
                fill()
                c.drawRoundRect(RectF(0.2f, 0.12f, 0.4f, 0.88f), 0.05f, 0.05f, p)
                c.drawRoundRect(RectF(0.6f, 0.12f, 0.8f, 0.88f), 0.05f, 0.05f, p)
            }
            Ic.NEXT -> {
                fill()
                poly(0.08f, 0.2f, 0.08f, 0.8f, 0.5f, 0.5f)
                poly(0.5f, 0.2f, 0.5f, 0.8f, 0.92f, 0.5f)
            }
        }
    }
}

class IconView(ctx: Context, var ic: Ic) : View(ctx) {
    var color: Int = Color.WHITE
    var frac: Float = 0.5f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat() * frac
        c.save()
        c.translate((width - s) / 2f, (height - s) / 2f)
        c.scale(s, s)
        IconPainter.draw(c, ic, p, color)
        c.restore()
    }
}

val TINT_RGB = intArrayOf(0xFFFFFF, 0x1C1C1E, 0x0A84FF, 0x5E5CE6, 0xFF375F, 0x30D158)
val TINT_NAMES = arrayOf("سفید", "تیره", "آبی", "بنفش", "صورتی", "سبز")

/** iOS-style glass slider. Vertical when tall, horizontal when wide. value is 0..1. */
class GSlider(
    ctx: Context,
    private val ic: Ic,
    initial: Float,
    private val track: Int,
    private val accent: Int,
    private val haptic: Boolean,
    private val onChange: (Float) -> Unit
) : View(ctx) {
    var value: Float = initial.coerceIn(0f, 1f)
    var dragging = false
    private var lastStep = (value * 10).toInt()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = Path()
    private val dens = resources.displayMetrics.density

    private fun horiz() = width > height * 1.2f

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val short = minOf(w, h)
        val r = short * 0.5f
        clip.reset()
        clip.addRoundRect(RectF(0f, 0f, w, h), r, r, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        p.style = Paint.Style.FILL
        if (track != 0) {
            p.color = track
            c.drawRect(0f, 0f, w, h, p)
        }
        p.color = 0xF2FFFFFF.toInt()
        if (horiz()) c.drawRect(0f, 0f, w * value, h, p) else c.drawRect(0f, h * (1f - value), w, h, p)
        c.restore()
        if (track != 0) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = dens
            p.color = 0x77FFFFFF
            c.drawRoundRect(RectF(dens / 2, dens / 2, w - dens / 2, h - dens / 2), r, r, p)
        }
        val s = short * 0.42f
        c.save()
        if (horiz()) c.translate(h * 0.28f, (h - s) / 2f) else c.translate((w - s) / 2f, h - s - w * 0.28f)
        c.scale(s, s)
        IconPainter.draw(c, ic, p, if (value > 0.14f) accent else Color.WHITE)
        c.restore()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
                value = (if (horiz()) e.x / width else 1f - e.y / height).coerceIn(0f, 1f)
                val st = (value * 10).toInt()
                if (st != lastStep) {
                    lastStep = st
                    if (haptic) performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                }
                onChange(value)
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragging = false
        }
        return true
    }
}

class ThinBar(ctx: Context) : View(ctx) {
    var value: Float = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = 0x55FFFFFF
        c.drawRoundRect(RectF(0f, 0f, w, h), h / 2, h / 2, p)
        p.color = Color.WHITE
        c.drawRoundRect(RectF(0f, 0f, w * value.coerceIn(0f, 1f), h), h / 2, h / 2, p)
    }
}

class MaxHeightScroll(ctx: Context, private val maxH: Int) : ScrollView(ctx) {
    override fun onMeasure(w: Int, h: Int) {
        super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
    }
}

/** Simple grid: fixed number of columns, each child spans cw x ch cells, packed first-fit. */
class CCGrid(ctx: Context, private val cols: Int, private val gap: Int) : ViewGroup(ctx) {
    class LP(val cw: Int, val ch: Int) : ViewGroup.LayoutParams(0, 0)

    private var cell = 0
    private var rowOf = IntArray(0)
    private var colOf = IntArray(0)

    override fun checkLayoutParams(p: ViewGroup.LayoutParams?): Boolean = p is LP
    override fun generateDefaultLayoutParams(): ViewGroup.LayoutParams = LP(1, 1)

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val width = MeasureSpec.getSize(wSpec)
        cell = (width - gap * (cols + 1)) / cols
        val n = childCount
        rowOf = IntArray(n)
        colOf = IntArray(n)
        val occ = ArrayList<BooleanArray>()
        fun free(r: Int, c: Int, cw: Int, ch: Int): Boolean {
            if (c + cw > cols) return false
            for (rr in r until r + ch) {
                if (rr < occ.size) {
                    for (cc in c until c + cw) if (occ[rr][cc]) return false
                }
            }
            return true
        }
        var maxRow = 0
        for (i in 0 until n) {
            val v = getChildAt(i)
            val lp = v.layoutParams as LP
            val cw = minOf(lp.cw, cols)
            var r = 0
            var c = 0
            var found = false
            while (!found) {
                c = 0
                while (c < cols) {
                    if (free(r, c, cw, lp.ch)) { found = true; break }
                    c++
                }
                if (!found) r++
            }
            while (occ.size < r + lp.ch) occ.add(BooleanArray(cols))
            for (rr in r until r + lp.ch) for (cc in c until c + cw) occ[rr][cc] = true
            rowOf[i] = r
            colOf[i] = c
            maxRow = maxOf(maxRow, r + lp.ch)
            val w = cw * cell + (cw - 1) * gap
            val h = lp.ch * cell + (lp.ch - 1) * gap
            v.measure(
                MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY)
            )
        }
        setMeasuredDimension(width, maxRow * cell + (maxRow + 1) * gap)
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        for (i in 0 until childCount) {
            val v = getChildAt(i)
            val x = gap + colOf[i] * (cell + gap)
            val y = gap + rowOf[i] * (cell + gap)
            v.layout(x, y, x + v.measuredWidth, y + v.measuredHeight)
        }
    }
}


/** "Liquid glass": translucent gradient fill, soft diagonal highlight, double rim bright at the corners. */
class GlassDrawable(
    private val density: Float,
    private val radiusDp: Float,
    private val oval: Boolean,
    private val fillTop: Int,
    private val fillBottom: Int
) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hi = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val inner = RectF()
    private var r = 0f

    override fun onBoundsChange(b: Rect) {
        val inset = density * 0.75f
        rect.set(b.left + inset, b.top + inset, b.right - inset, b.bottom - inset)
        val half = minOf(rect.width(), rect.height()) / 2f
        r = if (oval) half else minOf(radiusDp * density, half)
        fill.style = Paint.Style.FILL
        fill.shader = LinearGradient(
            rect.left, rect.top, rect.left, rect.bottom, fillTop, fillBottom, Shader.TileMode.CLAMP
        )
        hi.style = Paint.Style.FILL
        hi.shader = LinearGradient(
            rect.left, rect.top, rect.right, rect.bottom,
            intArrayOf(0x55FFFFFF, 0x00FFFFFF, 0x00FFFFFF, 0x2AFFFFFF),
            floatArrayOf(0f, 0.45f, 0.75f, 1f), Shader.TileMode.CLAMP
        )
        rim.style = Paint.Style.STROKE
        rim.strokeWidth = density * 1.25f
        rim.shader = LinearGradient(
            rect.left, rect.top, rect.right, rect.bottom,
            intArrayOf(0xF2FFFFFF.toInt(), 0x30FFFFFF, 0x30FFFFFF, 0xB8FFFFFF.toInt()),
            floatArrayOf(0f, 0.3f, 0.7f, 1f), Shader.TileMode.CLAMP
        )
        glow.style = Paint.Style.STROKE
        glow.strokeWidth = density
        glow.color = 0x22FFFFFF
    }

    override fun draw(c: Canvas) {
        if (rect.width() <= 0f || rect.height() <= 0f) return
        c.drawRoundRect(rect, r, r, fill)
        c.drawRoundRect(rect, r, r, hi)
        inner.set(rect.left + density * 2f, rect.top + density * 2f, rect.right - density * 2f, rect.bottom - density * 2f)
        val ir = maxOf(0f, r - density * 2f)
        c.drawRoundRect(inner, ir, ir, glow)
        c.drawRoundRect(rect, r, r, rim)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
