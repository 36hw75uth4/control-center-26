package com.example.cc

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

enum class Ic {
    WIFI, BT, AIRPLANE, DATA, TORCH, CAMERA, ALARM, GEAR, MOON, ROTATE,
    BATTERY, SUN, VOLUME, PREV, PLAY, PAUSE, NEXT
}

/** iOS-style icons drawn with Canvas in a 0..1 unit box. */
object IconPainter {
    fun draw(c: Canvas, ic: Ic, p: Paint, color: Int) {
        p.color = color
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        fun stroke(w: Float) { p.style = Paint.Style.STROKE; p.strokeWidth = w }
        fun fill() { p.style = Paint.Style.FILL }
        fun poly(vararg v: Float) {
            val path = Path()
            path.moveTo(v[0], v[1])
            var i = 2
            while (i < v.size) { path.lineTo(v[i], v[i + 1]); i += 2 }
            path.close()
            c.drawPath(path, p)
        }
        when (ic) {
            Ic.WIFI -> {
                stroke(0.09f)
                for (r in floatArrayOf(0.66f, 0.43f, 0.21f)) {
                    c.drawArc(RectF(0.5f - r, 0.84f - r, 0.5f + r, 0.84f + r), 225f, 90f, false, p)
                }
                fill()
                c.drawCircle(0.5f, 0.84f, 0.065f, p)
            }
            Ic.BT -> {
                stroke(0.09f)
                val path = Path()
                path.moveTo(0.22f, 0.30f)
                path.lineTo(0.74f, 0.70f)
                path.lineTo(0.5f, 0.92f)
                path.lineTo(0.5f, 0.08f)
                path.lineTo(0.74f, 0.30f)
                path.lineTo(0.22f, 0.70f)
                c.drawPath(path, p)
            }
            Ic.AIRPLANE -> {
                fill()
                c.save()
                c.rotate(90f, 0.5f, 0.5f)
                c.scale(1f / 24f, 1f / 24f)
                val path = Path()
                path.moveTo(21f, 16f); path.lineTo(21f, 14f); path.lineTo(13f, 9f); path.lineTo(13f, 3.5f)
                path.cubicTo(13f, 2.67f, 12.33f, 2f, 11.5f, 2f)
                path.cubicTo(10.67f, 2f, 10f, 2.67f, 10f, 3.5f)
                path.lineTo(10f, 9f); path.lineTo(2f, 14f); path.lineTo(2f, 16f); path.lineTo(10f, 13.5f)
                path.lineTo(10f, 19f); path.lineTo(8f, 20.5f); path.lineTo(8f, 22f); path.lineTo(11.5f, 21f)
                path.lineTo(15f, 22f); path.lineTo(15f, 20.5f); path.lineTo(13f, 19f); path.lineTo(13f, 13.5f)
                path.close()
                c.drawPath(path, p)
                c.restore()
            }
            Ic.DATA -> {
                fill()
                for (i in 0..3) {
                    val l = 0.1f + i * 0.22f
                    val h = 0.25f + i * 0.18f
                    c.drawRoundRect(RectF(l, 0.9f - h, l + 0.14f, 0.9f), 0.04f, 0.04f, p)
                }
            }
            Ic.TORCH -> {
                fill()
                val path = Path()
                path.fillType = Path.FillType.EVEN_ODD
                path.moveTo(0.27f, 0.06f); path.lineTo(0.73f, 0.06f); path.lineTo(0.73f, 0.2f)
                path.lineTo(0.62f, 0.34f); path.lineTo(0.62f, 0.94f); path.lineTo(0.38f, 0.94f)
                path.lineTo(0.38f, 0.34f); path.lineTo(0.27f, 0.2f); path.close()
                path.addCircle(0.5f, 0.55f, 0.05f, Path.Direction.CW)
                c.drawPath(path, p)
            }
            Ic.CAMERA -> {
                fill()
                val path = Path()
                path.fillType = Path.FillType.EVEN_ODD
                path.addRoundRect(RectF(0.05f, 0.26f, 0.95f, 0.84f), 0.12f, 0.12f, Path.Direction.CW)
                path.addCircle(0.5f, 0.55f, 0.18f, Path.Direction.CW)
                c.drawPath(path, p)
                c.drawRoundRect(RectF(0.3f, 0.14f, 0.7f, 0.3f), 0.05f, 0.05f, p)
            }
            Ic.ALARM -> {
                stroke(0.08f)
                c.drawCircle(0.5f, 0.56f, 0.33f, p)
                c.drawLine(0.5f, 0.56f, 0.5f, 0.38f, p)
                c.drawLine(0.5f, 0.56f, 0.64f, 0.64f, p)
                fill()
                c.drawCircle(0.16f, 0.2f, 0.1f, p)
                c.drawCircle(0.84f, 0.2f, 0.1f, p)
            }
            Ic.GEAR -> {
                stroke(0.11f)
                c.drawCircle(0.5f, 0.5f, 0.24f, p)
                fill()
                for (i in 0..7) {
                    c.save()
                    c.rotate(i * 45f, 0.5f, 0.5f)
                    c.drawRoundRect(RectF(0.43f, 0.06f, 0.57f, 0.24f), 0.03f, 0.03f, p)
                    c.restore()
                }
            }
            Ic.MOON -> {
                fill()
                c.save()
                c.scale(0.01f, 0.01f)
                val a = Path()
                a.addCircle(50f, 50f, 40f, Path.Direction.CW)
                val b = Path()
                b.addCircle(72f, 34f, 34f, Path.Direction.CW)
                a.op(b, Path.Op.DIFFERENCE)
                c.drawPath(a, p)
                c.restore()
            }
            Ic.ROTATE -> {
                stroke(0.085f)
                c.drawArc(RectF(0.12f, 0.12f, 0.88f, 0.88f), 300f, 280f, false, p)
                fill()
                poly(0.286f, 0.164f, 0.286f, 0.320f, 0.132f, 0.192f)
                c.drawRoundRect(RectF(0.4f, 0.48f, 0.6f, 0.66f), 0.03f, 0.03f, p)
                stroke(0.05f)
                c.drawArc(RectF(0.43f, 0.36f, 0.57f, 0.54f), 180f, 180f, false, p)
            }
            Ic.BATTERY -> {
                stroke(0.07f)
                c.drawRoundRect(RectF(0.06f, 0.28f, 0.82f, 0.72f), 0.1f, 0.1f, p)
                fill()
                c.drawRoundRect(RectF(0.86f, 0.43f, 0.95f, 0.57f), 0.03f, 0.03f, p)
                c.drawRoundRect(RectF(0.15f, 0.37f, 0.55f, 0.63f), 0.05f, 0.05f, p)
            }
            Ic.SUN -> {
                fill()
                c.drawCircle(0.5f, 0.5f, 0.17f, p)
                stroke(0.07f)
                for (i in 0..7) {
                    c.save()
                    c.rotate(i * 45f, 0.5f, 0.5f)
                    c.drawLine(0.5f, 0.08f, 0.5f, 0.2f, p)
                    c.restore()
                }
            }
            Ic.VOLUME -> {
                fill()
                poly(0.1f, 0.38f, 0.28f, 0.38f, 0.5f, 0.18f, 0.5f, 0.82f, 0.28f, 0.62f, 0.1f, 0.62f)
                stroke(0.07f)
                c.drawArc(RectF(0.38f, 0.3f, 0.78f, 0.7f), -45f, 90f, false, p)
                c.drawArc(RectF(0.24f, 0.16f, 0.92f, 0.84f), -45f, 90f, false, p)
            }
            Ic.PREV -> {
                fill()
                poly(0.92f, 0.2f, 0.92f, 0.8f, 0.5f, 0.5f)
                poly(0.5f, 0.2f, 0.5f, 0.8f, 0.08f, 0.5f)
            }
            Ic.PLAY -> {
                fill()
                poly(0.25f, 0.12f, 0.25f, 0.88f, 0.85f, 0.5f)
            }
            Ic.PAUSE -> {
                fill()
                c.drawRoundRect(RectF(0.2f, 0.12f, 0.4f, 0.88f), 0.05f, 0.05f, p)
                c.drawRoundRect(RectF(0.6f, 0.12f, 0.8f, 0.88f), 0.05f, 0.05f, p)
            }
            Ic.NEXT -> {
                fill()
                poly(0.08f, 0.2f, 0.08f, 0.8f, 0.5f, 0.5f)
                poly(0.5f, 0.2f, 0.5f, 0.8f, 0.92f, 0.5f)
            }
        }
    }
}

class IconView(ctx: Context, var ic: Ic) : View(ctx) {
    var color: Int = Color.WHITE
    var frac: Float = 0.5f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val s = minOf(width, height).toFloat() * frac
        c.save()
        c.translate((width - s) / 2f, (height - s) / 2f)
        c.scale(s, s)
        IconPainter.draw(c, ic, p, color)
        c.restore()
    }
}

/** iOS-style vertical glass slider. value is 0..1. */
class VSlider(
    ctx: Context,
    private val ic: Ic,
    initial: Float,
    private val onChange: (Float) -> Unit
) : View(ctx) {
    var value: Float = initial.coerceIn(0f, 1f)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = Path()
    private val dens = resources.displayMetrics.density

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = w * 0.42f
        clip.reset()
        clip.addRoundRect(RectF(0f, 0f, w, h), r, r, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        p.style = Paint.Style.FILL
        p.color = 0x44FFFFFF
        c.drawRect(0f, 0f, w, h, p)
        p.color = 0xF2FFFFFF.toInt()
        c.drawRect(0f, h * (1f - value), w, h, p)
        c.restore()
        p.style = Paint.Style.STROKE
        p.strokeWidth = dens
        p.color = 0x77FFFFFF
        c.drawRoundRect(RectF(dens / 2, dens / 2, w - dens / 2, h - dens / 2), r, r, p)
        val s = w * 0.42f
        c.save()
        c.translate((w - s) / 2f, h - s - w * 0.28f)
        c.scale(s, s)
        IconPainter.draw(c, ic, p, if (value > 0.14f) 0xFF55585C.toInt() else Color.WHITE)
        c.restore()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                value = (1f - e.y / height).coerceIn(0f, 1f)
                onChange(value)
                invalidate()
            }
        }
        return true
    }
}
