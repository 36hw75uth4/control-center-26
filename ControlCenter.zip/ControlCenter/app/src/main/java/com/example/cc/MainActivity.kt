package com.example.cc

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var blurLabel: TextView? = null

    private fun updateBlurState() {
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        blurLabel?.text = if (s.contains(packageName)) {
            "وضعیت: فعال ✅"
        } else {
            "وضعیت: غیرفعال. «Control Center Blur» رو روشن کن. اگه خاکستریه: تنظیمات > برنامه‌ها > Control Center > ⋮ > Allow restricted settings"
        }
    }

    override fun onResume() {
        super.onResume()
        updateBlurState()
    }

    private fun restart() {
        stopService(Intent(this, ControlCenterService::class.java))
        if (Settings.canDrawOverlays(this)) {
            startForegroundService(Intent(this, ControlCenterService::class.java))
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("cc", MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad)

        fun label(t: String, size: Float): TextView {
            val tv = TextView(this)
            tv.text = t
            tv.textSize = size
            tv.setPadding(0, pad / 2, 0, pad / 4)
            return tv
        }
        fun btn(t: String, a: () -> Unit): Button {
            val bt = Button(this)
            bt.text = t
            bt.setOnClickListener { a() }
            return bt
        }
        fun radios(names: Array<String>, base: Int, current: Int, onPick: (Int) -> Unit): RadioGroup {
            val rg = RadioGroup(this)
            names.forEachIndexed { i, n ->
                val rb = RadioButton(this)
                rb.text = n
                rb.id = base + i
                rg.addView(rb)
            }
            rg.check(base + current)
            rg.setOnCheckedChangeListener { _, id -> onPick(id - base) }
            return rg
        }

        val title = label("Control Center", 26f)
        title.gravity = Gravity.CENTER
        col.addView(title)

        col.addView(btn("1) اجازه نمایش روی برنامه‌ها") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("2) شروع") {
            if (Settings.canDrawOverlays(this)) {
                startForegroundService(Intent(this, ControlCenterService::class.java))
                Toast.makeText(this, "کنترل سنتر فعال شد", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "اول مرحله ۱", Toast.LENGTH_SHORT).show()
            }
        })
        col.addView(btn("توقف") { stopService(Intent(this, ControlCenterService::class.java)) })

        col.addView(label("نحوه باز شدن:", 16f))
        col.addView(radios(
            arrayOf("کشیدن به پایین از بالای صفحه", "کشیدن از لبه صفحه", "دو بار ضربه روی بالای صفحه"),
            200, prefs.getInt("gesture", 0)
        ) { i ->
            prefs.edit().putInt("gesture", i).apply()
            restart()
        })

        col.addView(label("محل ناحیه لمس:", 16f))
        col.addView(radios(
            arrayOf("راست", "چپ", "وسط", "کل عرض (فقط بالا)"),
            100, prefs.getInt("pos", 0)
        ) { i ->
            prefs.edit().putInt("pos", i).apply()
            restart()
        })

        col.addView(label("شفافیت شیشه:", 16f))
        val sb = SeekBar(this)
        sb.max = 80
        sb.progress = prefs.getInt("alpha", 40) - 10
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                if (u) prefs.edit().putInt("alpha", p + 10).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        col.addView(sb)

        col.addView(label("رنگ شیشه:", 16f))
        col.addView(radios(TINT_NAMES, 300, prefs.getInt("tint", 0)) { i ->
            prefs.edit().putInt("tint", i).apply()
        })

        val cb = CheckBox(this)
        cb.text = "لرزش هنگام لمس"
        cb.isChecked = prefs.getBoolean("haptic", true)
        cb.setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("haptic", c).apply() }
        col.addView(cb)

        col.addView(label("بلر کامل صفحه:", 16f))
        val bl = label("", 13f)
        blurLabel = bl
        col.addView(bl)
        col.addView(btn("فعال‌سازی بلر (دسترسی‌پذیری)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(label("اختیاری:", 16f))
        col.addView(btn("دسترسی اعلان‌ها (نام آهنگ و عکس)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(btn("بازنشانی چیدمان دکمه‌ها") {
            prefs.edit().remove("layout2").apply()
            Toast.makeText(this, "چیدمان به حالت اول برگشت", Toast.LENGTH_SHORT).show()
        })

        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }
}
