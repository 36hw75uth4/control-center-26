package com.example.cc

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private fun restart() {
        stopService(Intent(this, ControlCenterService::class.java))
        if (Settings.canDrawOverlays(this)) {
            startForegroundService(Intent(this, ControlCenterService::class.java))
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("cc", MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad)

        fun label(t: String, size: Float): TextView {
            val tv = TextView(this)
            tv.text = t
            tv.textSize = size
            tv.setPadding(0, pad / 2, 0, pad / 4)
            return tv
        }
        fun btn(t: String, a: () -> Unit): Button {
            val bt = Button(this)
            bt.text = t
            bt.setOnClickListener { a() }
            return bt
        }

        val title = label("Control Center", 26f)
        title.gravity = Gravity.CENTER
        col.addView(title)

        col.addView(btn("1) اجازه نمایش روی برنامه‌ها") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("2) شروع") {
            if (Settings.canDrawOverlays(this)) {
                startForegroundService(Intent(this, ControlCenterService::class.java))
                Toast.makeText(this, "از بالای صفحه به پایین بکش", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "اول مرحله ۱", Toast.LENGTH_SHORT).show()
            }
        })
        col.addView(btn("توقف") { stopService(Intent(this, ControlCenterService::class.java)) })

        col.addView(label("محل کشیدن برای باز شدن:", 16f))
        val rg = RadioGroup(this)
        val names = arrayOf("بالا-راست", "بالا-چپ", "بالا-وسط", "کل عرض بالا")
        names.forEachIndexed { i, n ->
            val rb = RadioButton(this)
            rb.text = n
            rb.id = 100 + i
            rg.addView(rb)
        }
        rg.check(100 + prefs.getInt("pos", 0))
        rg.setOnCheckedChangeListener { _, id ->
            prefs.edit().putInt("pos", id - 100).apply()
            restart()
        }
        col.addView(rg)

        col.addView(label("اختیاری:", 16f))
        col.addView(btn("دسترسی اعلان‌ها (نمایش نام آهنگ)") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })

        val sv = ScrollView(this)
        sv.addView(col)
        setContentView(sv)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }
}
