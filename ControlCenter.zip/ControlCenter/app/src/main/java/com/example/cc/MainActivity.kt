package com.example.cc

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        fun btn(t: String, a: () -> Unit) = Button(this).apply {
            text = t
            setOnClickListener { a() }
        }
        col.addView(TextView(this).apply { text = "Control Center"; textSize = 26f; gravity = Gravity.CENTER })
        col.addView(btn("1) اجازه نمایش روی برنامه‌ها") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("2) شروع") {
            if (Settings.canDrawOverlays(this)) {
                startForegroundService(Intent(this, ControlCenterService::class.java))
                Toast.makeText(this, "از گوشه بالا-راست به پایین بکش", Toast.LENGTH_LONG).show()
            } else Toast.makeText(this, "اول مرحله ۱", Toast.LENGTH_SHORT).show()
        })
        col.addView(btn("توقف") { stopService(Intent(this, ControlCenterService::class.java)) })
        setContentView(col)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }
}
