package com.example.cc

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class ControlCenterService : Service() {
    private class Style(val r: Int, val oval: Boolean)

    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT
    private val BLUE = 0xFF0A84FF.toInt()
    private val ORANGE = 0xFFFF9F0A.toInt()
    private val PURPLE = 0xFF5E5CE6.toInt()

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var cam: CameraManager
    private lateinit var audio: AudioManager
    private lateinit var nm: NotificationManager

    private var trigger: View? = null
    private var panel: View? = null
    private var torchId: String? = null
    private var torchOn = false
    private var torchTile: FrameLayout? = null
    private var askedWrite = false

    private var musicTitle: TextView? = null
    private var musicArtist: TextView? = null
    private var playIcon: IconView? = null

    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(id: String, enabled: Boolean) {
            torchOn = enabled
            torchTile?.let { setOn(it, enabled) }
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (panel != null) {
                updateMusic()
                handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        cam = getSystemService(CAMERA_SERVICE) as CameraManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        nm = getSystemService(NotificationManager::class.java)
        torchId = try {
            cam.cameraIdList.firstOrNull {
                cam.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (e: Exception) { null }
        cam.registerTorchCallback(torchCb, null)

        nm.createNotificationChannel(NotificationChannel("cc", "Control Center", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "cc")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Control Center")
            .setContentText("از بالای صفحه به پایین بکش")
            .build()
        startForeground(1, n)
        addTrigger()
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        trigger?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        cam.unregisterTorchCallback(torchCb)
        super.onDestroy()
    }

    // ---------- helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun glass(r: Int, oval: Boolean = false, on: Int? = null): GradientDrawable {
        val d = if (on != null) {
            val s = GradientDrawable()
            s.setColor(on)
            s
        } else {
            GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0x66FFFFFF, 0x1FFFFFFF))
        }
        if (oval) d.shape = GradientDrawable.OVAL else d.cornerRadius = dp(r).toFloat()
        d.setStroke(dp(1), 0x77FFFFFF)
        return d
    }

    private fun lp(w: Int, h: Int, wt: Float = 0f): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h, wt)
        p.setMargins(dp(6), dp(6), dp(6), dp(6))
        return p
    }

    private fun tile(ic: Ic, r: Int, oval: Boolean, onClick: (FrameLayout) -> Unit): FrameLayout {
        val f = FrameLayout(this)
        f.tag = Style(r, oval)
        f.background = glass(r, oval)
        val iv = IconView(this, ic)
        iv.frac = 0.46f
        f.addView(iv, FrameLayout.LayoutParams(MP, MP))
        f.setOnClickListener { onClick(f) }
        return f
    }

    private fun setOn(f: FrameLayout, on: Boolean, color: Int = Color.WHITE) {
        val s = f.tag as Style
        f.background = if (on) glass(s.r, s.oval, color) else glass(s.r, s.oval)
        val iv = f.getChildAt(0) as IconView
        iv.color = if (on && color == Color.WHITE) 0xFF3A3A3C.toInt() else Color.WHITE
        iv.invalidate()
    }

    private fun go(i: Intent) {
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        hidePanel()
    }

    private fun writeSettingsIntent() =
        Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))

    private fun key(code: Int) {
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun hasListenerAccess(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return s != null && s.contains(packageName)
    }

    private fun wifiOn(): Boolean = try {
        (applicationContext.getSystemService(WIFI_SERVICE) as WifiManager).isWifiEnabled
    } catch (e: Exception) { false }

    private fun btOn(): Boolean = try {
        BluetoothAdapter.getDefaultAdapter()?.isEnabled == true
    } catch (e: Exception) { false }

    private fun airplaneOn(): Boolean =
        Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1

    private fun dndOn(): Boolean {
        if (!nm.isNotificationPolicyAccessGranted) return false
        val f = nm.currentInterruptionFilter
        return f != NotificationManager.INTERRUPTION_FILTER_ALL &&
            f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
    }

    // ---------- trigger (swipe-down area) ----------

    private fun addTrigger() {
        val v = View(this)
        v.setBackgroundColor(0x01FFFFFF)
        var startY = 0f
        var fired = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { startY = e.rawY; fired = false }
                MotionEvent.ACTION_MOVE -> if (!fired && e.rawY - startY > dp(40)) {
                    fired = true
                    showPanel()
                }
            }
            true
        }
        val pos = getSharedPreferences("cc", MODE_PRIVATE).getInt("pos", 0)
        val width = if (pos == 3) MP else dp(140)
        val lp = WindowManager.LayoutParams(
            width, dp(24), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = when (pos) {
            1 -> Gravity.TOP or Gravity.START
            2 -> Gravity.TOP or Gravity.CENTER_HORIZONTAL
            3 -> Gravity.TOP
            else -> Gravity.TOP or Gravity.END
        }
        wm.addView(v, lp)
        trigger = v
    }

    // ---------- music ----------

    private fun updateMusic() {
        val t = musicTitle ?: return
        val a = musicArtist ?: return
        if (!hasListenerAccess()) {
            t.text = "در حال پخش"
            a.text = "برای نمایش نام آهنگ اینجا بزن"
            return
        }
        val c = try {
            getSystemService(MediaSessionManager::class.java)
                .getActiveSessions(ComponentName(this, MediaListenerService::class.java))
                .firstOrNull()
        } catch (e: Exception) { null }
        if (c == null) {
            t.text = "پخش نمی‌شود"
            a.text = ""
            playIcon?.ic = Ic.PLAY
            playIcon?.invalidate()
            return
        }
        val md = c.metadata
        t.text = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "—"
        a.text = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        playIcon?.ic = if (c.playbackState?.state == PlaybackState.STATE_PLAYING) Ic.PAUSE else Ic.PLAY
        playIcon?.invalidate()
    }

    private fun musicCard(): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = glass(30)
        box.setPadding(dp(14), dp(14), dp(14), dp(10))

        val title = TextView(this)
        title.setTextColor(Color.WHITE)
        title.textSize = 15f
        title.setTypeface(title.typeface, android.graphics.Typeface.BOLD)
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        val artist = TextView(this)
        artist.setTextColor(0xCCFFFFFF.toInt())
        artist.textSize = 12f
        artist.maxLines = 2
        artist.ellipsize = TextUtils.TruncateAt.END
        musicTitle = title
        musicArtist = artist

        val textBox = LinearLayout(this)
        textBox.orientation = LinearLayout.VERTICAL
        textBox.addView(title)
        textBox.addView(artist)
        textBox.setOnClickListener {
            if (!hasListenerAccess()) go(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        box.addView(textBox, LinearLayout.LayoutParams(MP, 0, 1f))

        val controls = LinearLayout(this)
        controls.orientation = LinearLayout.HORIZONTAL
        controls.gravity = Gravity.CENTER
        fun mk(ic: Ic, code: Int): IconView {
            val iv = IconView(this, ic)
            iv.frac = 0.5f
            iv.setOnClickListener { key(code) }
            controls.addView(iv, LinearLayout.LayoutParams(0, dp(44), 1f))
            return iv
        }
        mk(Ic.PREV, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        playIcon = mk(Ic.PLAY, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
        mk(Ic.NEXT, KeyEvent.KEYCODE_MEDIA_NEXT)
        box.addView(controls, LinearLayout.LayoutParams(MP, WC))
        return box
    }

    // ---------- panel ----------

    private fun showPanel() {
        if (panel != null) return
        askedWrite = false

        val root = FrameLayout(this)
        root.setBackgroundColor(0x55000000)
        root.setOnClickListener { hidePanel() }

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.isClickable = true
        card.setPadding(dp(10), dp(10), dp(10), dp(10))

        // Row 1: connectivity + music
        val row1 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL

        val conn = LinearLayout(this)
        conn.orientation = LinearLayout.VERTICAL
        conn.gravity = Gravity.CENTER
        conn.background = glass(30)
        val c1 = LinearLayout(this)
        c1.gravity = Gravity.CENTER
        val c2 = LinearLayout(this)
        c2.gravity = Gravity.CENTER

        val wifi = tile(Ic.WIFI, 0, true) { go(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) }
        val bt = tile(Ic.BT, 0, true) { go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        val air = tile(Ic.AIRPLANE, 0, true) { go(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) }
        val data = tile(Ic.DATA, 0, true) { go(Intent(Settings.ACTION_DATA_ROAMING_SETTINGS)) }
        setOn(wifi, wifiOn(), BLUE)
        setOn(bt, btOn(), BLUE)
        setOn(air, airplaneOn(), ORANGE)
        c1.addView(wifi, lp(dp(56), dp(56)))
        c1.addView(bt, lp(dp(56), dp(56)))
        c2.addView(air, lp(dp(56), dp(56)))
        c2.addView(data, lp(dp(56), dp(56)))
        conn.addView(c1)
        conn.addView(c2)
        row1.addView(conn, lp(0, dp(160), 1f))
        row1.addView(musicCard(), lp(0, dp(160), 1f))
        card.addView(row1)

        // Row 2: rotation + DND on the left, two vertical sliders on the right
        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        val left = LinearLayout(this)
        left.orientation = LinearLayout.VERTICAL

        val rot = tile(Ic.ROTATE, 24, false) { f ->
            if (!Settings.System.canWrite(this)) {
                go(writeSettingsIntent())
            } else {
                val locked = Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 0
                Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (locked) 1 else 0)
                setOn(f, !locked)
            }
        }
        setOn(rot, Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 0)

        val dnd = tile(Ic.MOON, 24, false) { f ->
            if (!nm.isNotificationPolicyAccessGranted) {
                go(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            } else {
                val on = dndOn()
                nm.setInterruptionFilter(
                    if (on) NotificationManager.INTERRUPTION_FILTER_ALL
                    else NotificationManager.INTERRUPTION_FILTER_PRIORITY
                )
                setOn(f, !on, PURPLE)
            }
        }
        setOn(dnd, dndOn(), PURPLE)
        left.addView(rot, lp(MP, 0, 1f))
        left.addView(dnd, lp(MP, 0, 1f))
        row2.addView(left, lp(0, dp(160), 1f))

        val curB = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
        val bright = VSlider(this, Ic.SUN, curB / 255f) { v ->
            if (!Settings.System.canWrite(this)) {
                if (!askedWrite) {
                    askedWrite = true
                    go(writeSettingsIntent())
                }
            } else {
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS,
                    (v * 255).toInt().coerceIn(1, 255))
            }
        }
        val maxV = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val curV = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        val vol = VSlider(this, Ic.VOLUME, if (maxV > 0) curV.toFloat() / maxV else 0f) { v ->
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(v * maxV), 0)
        }
        row2.addView(bright, lp(0, dp(160), 0.5f))
        row2.addView(vol, lp(0, dp(160), 0.5f))
        card.addView(row2)

        // Row 3: shortcuts
        val row3 = LinearLayout(this)
        row3.orientation = LinearLayout.HORIZONTAL
        val torch = tile(Ic.TORCH, 22, false) {
            try { torchId?.let { id -> cam.setTorchMode(id, !torchOn) } } catch (_: Exception) {}
        }
        torchTile = torch
        setOn(torch, torchOn)
        val alarm = tile(Ic.ALARM, 22, false) { go(Intent(AlarmClock.ACTION_SHOW_ALARMS)) }
        val gear = tile(Ic.GEAR, 22, false) { go(Intent(Settings.ACTION_SETTINGS)) }
        val batt = tile(Ic.BATTERY, 22, false) { go(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) }
        val camera = tile(Ic.CAMERA, 22, false) { go(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }
        for (t in listOf(torch, alarm, gear, batt, camera)) row3.addView(t, lp(0, dp(64), 1f))
        card.addView(row3)

        root.addView(card, FrameLayout.LayoutParams(MP, WC).apply { setMargins(dp(14), dp(56), dp(14), 0) })

        val params = WindowManager.LayoutParams(
            MP, MP, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 31) {
            params.flags = params.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            params.blurBehindRadius = 90
        }
        wm.addView(root, params)
        panel = root

        root.alpha = 0f
        card.translationY = -dp(80).toFloat()
        root.animate().alpha(1f).setDuration(220).start()
        card.animate().translationY(0f).setDuration(300).setInterpolator(DecelerateInterpolator()).start()

        updateMusic()
        handler.postDelayed(ticker, 1000)
    }

    private fun hidePanel() {
        val p = panel ?: return
        panel = null
        handler.removeCallbacks(ticker)
        musicTitle = null
        musicArtist = null
        playIcon = null
        torchTile = null
        p.animate().alpha(0f).setDuration(160).withEndAction {
            try { wm.removeView(p) } catch (_: Exception) {}
        }.start()
    }
}
