package com.example.cc

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.text.TextUtils
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

const val DEFAULT_LAYOUT =
    "CONNECT:2:2;MUSIC:2:2;ROTATE:1:1;MIRROR:1:1;BRIGHT:1:2;VOL:1:2;DND:2:1;TORCH:1:1;TIMER:1:1;CALC:1:1;CAMERA:1:1;QR:1:1"

class ControlCenterService : Service() {
    private class Style(val r: Int, val oval: Boolean, val base: Int?)
    private class Def(val name: String, val sizes: List<Pair<Int, Int>>)
    private class Item(var id: String, var cw: Int, var ch: Int)

    private val tileSizes = listOf(1 to 1, 2 to 1, 2 to 2)
    private val sliderSizes = listOf(1 to 2, 2 to 1, 4 to 1)
    private val defs = linkedMapOf(
        "CONNECT" to Def("اتصالات", listOf(2 to 2)),
        "MUSIC" to Def("پخش‌کننده", listOf(2 to 2, 4 to 2)),
        "ROTATE" to Def("قفل چرخش", tileSizes),
        "DND" to Def("مزاحم نشوید", listOf(2 to 1, 1 to 1)),
        "BRIGHT" to Def("روشنایی", sliderSizes),
        "VOL" to Def("صدا", sliderSizes),
        "WIFI" to Def("وای‌فای", tileSizes),
        "BT" to Def("بلوتوث", tileSizes),
        "AIR" to Def("حالت پرواز", tileSizes),
        "DATA" to Def("دیتا", tileSizes),
        "TORCH" to Def("چراغ قوه", tileSizes),
        "ALARM" to Def("آلارم", tileSizes),
        "TIMER" to Def("تایمر", tileSizes),
        "CALC" to Def("ماشین‌حساب", tileSizes),
        "GEAR" to Def("تنظیمات", tileSizes),
        "BATT" to Def("حالت باتری", tileSizes),
        "CAMERA" to Def("دوربین", tileSizes),
        "QSHARE" to Def("کوییک شر", tileSizes),
        "MIRROR" to Def("آینه‌سازی صفحه", tileSizes),
        "QR" to Def("اسکن QR", tileSizes)
    )

    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT
    private val BLUE = 0xFF0A84FF.toInt()
    private val ORANGE = 0xFFFF9F0A.toInt()
    private val PURPLE = 0xFF5E5CE6.toInt()

    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("cc", MODE_PRIVATE) }
    private lateinit var wm: WindowManager
    private lateinit var cam: CameraManager
    private lateinit var audio: AudioManager
    private lateinit var nm: NotificationManager

    private var trigger: View? = null
    private var panel: View? = null
    private var grid: CCGrid? = null
    private var toolbar: View? = null
    private var editBtn: IconView? = null
    private var cellPx = 0
    private var items: MutableList<Item> = ArrayList()
    private var editMode = false
    private var selected = -1

    private var torchId: String? = null
    private var torchOn = false
    private var torchMax = 1
    private var torchStep = 0
    private var torchLevel = 0
    private var torchTile: FrameLayout? = null
    private var askedWrite = false

    private var musicTitle: TextView? = null
    private var musicArtist: TextView? = null
    private var musicArt: ImageView? = null
    private var musicBar: ThinBar? = null
    private var playIcon: IconView? = null

    private var gA = 0x66
    private var tintRgb = 0xFFFFFF
    private var hapticOn = true

    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(id: String, enabled: Boolean) {
            torchOn = enabled
            torchTile?.let { setOn(it, enabled) }
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (panel != null) {
                updateMusic()
                handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        cam = getSystemService(CAMERA_SERVICE) as CameraManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        nm = getSystemService(NotificationManager::class.java)
        torchId = try {
            cam.cameraIdList.firstOrNull {
                cam.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
        } catch (e: Exception) { null }
        torchMax = try {
            val id = torchId
            if (id != null && Build.VERSION.SDK_INT >= 33) {
                cam.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL) ?: 1
            } else 1
        } catch (e: Exception) { 1 }
        cam.registerTorchCallback(torchCb, null)

        nm.createNotificationChannel(NotificationChannel("cc", "Control Center", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "cc")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Control Center")
            .setContentText("Control Center فعال است")
            .build()
        startForeground(1, n)
        addTrigger()
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        trigger?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        cam.unregisterTorchCallback(torchCb)
        super.onDestroy()
    }

    // ---------- helpers ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun haptic(v: View) { if (hapticOn) v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY) }

    private fun trackColor(): Int = ((gA + 0x10).coerceAtMost(255) shl 24) or tintRgb

    private fun glass(r: Int, oval: Boolean = false, on: Int? = null, base: Int? = null): Drawable {
        val top: Int
        val bottom: Int
        if (on != null) {
            top = (0xF2 shl 24) or (on and 0xFFFFFF)
            bottom = (0xD8 shl 24) or (on and 0xFFFFFF)
        } else if (base != null) {
            top = (0xB0 shl 24) or base
            bottom = (0x80 shl 24) or base
        } else {
            top = (gA shl 24) or tintRgb
            bottom = ((gA * 60 / 100) shl 24) or tintRgb
        }
        return GlassDrawable(resources.displayMetrics.density, r.toFloat(), oval, top, bottom)
    }

    private fun statusBarH(): Int {
        val id = resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else dp(24)
    }

    private fun lp(w: Int, h: Int, wt: Float = 0f): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h, wt)
        p.setMargins(dp(4), dp(4), dp(4), dp(4))
        return p
    }

    private fun pressFx(v: View) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(0.93f).scaleY(0.93f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f).setDuration(240)
                        .setInterpolator(OvershootInterpolator(2f)).start()
            }
            false
        }
    }

    private fun tile(ic: Ic, r: Int, oval: Boolean, base: Int? = null, onClick: (FrameLayout) -> Unit): FrameLayout {
        val f = FrameLayout(this)
        f.tag = Style(r, oval, base)
        f.background = glass(r, oval, null, base)
        val iv = IconView(this, ic)
        iv.frac = 0.46f
        f.addView(iv, FrameLayout.LayoutParams(MP, MP))
        f.setOnClickListener { haptic(f); onClick(f) }
        pressFx(f)
        return f
    }

    private fun setOn(f: FrameLayout, on: Boolean, color: Int = Color.WHITE, icon: Int? = null) {
        val s = f.tag as Style
        f.background = if (on) glass(s.r, s.oval, color) else glass(s.r, s.oval, null, s.base)
        val iv = f.getChildAt(0) as IconView
        iv.color = icon ?: (if (on && color == Color.WHITE) 0xFF3A3A3C.toInt() else Color.WHITE)
        iv.invalidate()
    }

    private fun go(i: Intent) {
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        hidePanel()
    }

    private fun writeSettingsIntent() =
        Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))

    private fun key(code: Int) {
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun hasListenerAccess(): Boolean {
        val s = Settings.Secure.getString(contentResolver, "enabled_notification_listeners")
        return s != null && s.contains(packageName)
    }

    private fun wifiOn(): Boolean = try {
        (applicationContext.getSystemService(WIFI_SERVICE) as WifiManager).isWifiEnabled
    } catch (e: Exception) { false }

    private fun btOn(): Boolean = try {
        BluetoothAdapter.getDefaultAdapter()?.isEnabled == true
    } catch (e: Exception) { false }

    private fun airplaneOn(): Boolean =
        Settings.Global.getInt(contentResolver, Settings.Global.AIRPLANE_MODE_ON, 0) == 1

    private fun dndOn(): Boolean {
        if (!nm.isNotificationPolicyAccessGranted) return false
        val f = nm.currentInterruptionFilter
        return f != NotificationManager.INTERRUPTION_FILTER_ALL &&
            f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN
    }

    private fun rotationLocked(): Boolean =
        Settings.System.getInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, 1) == 0

    // ---------- trigger ----------

    private fun addTrigger() {
        val pos = prefs.getInt("pos", 0)
        val mode = prefs.getInt("gesture", 0)
        val v = View(this)
        v.setBackgroundColor(0x01FFFFFF)
        var w = dp(140)
        var h = dp(24)
        var g = Gravity.TOP or Gravity.END

        if (mode == 1) {
            // edge swipe
            w = dp(16)
            h = (resources.displayMetrics.heightPixels * 0.4f).toInt()
            g = (if (pos == 1) Gravity.START else Gravity.END) or Gravity.CENTER_VERTICAL
            var startX = 0f
            var fired = false
            v.setOnTouchListener { _, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { startX = e.rawX; fired = false }
                    MotionEvent.ACTION_MOVE -> {
                        val d = if (pos == 1) e.rawX - startX else startX - e.rawX
                        if (!fired && d > dp(40)) { fired = true; showPanel() }
                    }
                }
                true
            }
        } else {
            if (pos == 3) w = MP
            g = when (pos) {
                1 -> Gravity.TOP or Gravity.START
                2 -> Gravity.TOP or Gravity.CENTER_HORIZONTAL
                3 -> Gravity.TOP
                else -> Gravity.TOP or Gravity.END
            }
            if (mode == 2) {
                // double tap
                h = dp(32)
                val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
                    override fun onDown(e: MotionEvent): Boolean = true
                    override fun onDoubleTap(e: MotionEvent): Boolean {
                        showPanel()
                        return true
                    }
                })
                v.setOnTouchListener { _, e -> gd.onTouchEvent(e); true }
            } else {
                // swipe down
                var startY = 0f
                var fired = false
                v.setOnTouchListener { _, e ->
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> { startY = e.rawY; fired = false }
                        MotionEvent.ACTION_MOVE -> if (!fired && e.rawY - startY > dp(40)) {
                            fired = true
                            showPanel()
                        }
                    }
                    true
                }
            }
        }
        val lp = WindowManager.LayoutParams(
            w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = g
        wm.addView(v, lp)
        trigger = v
    }

    // ---------- layout persistence ----------

    private fun loadItems(): MutableList<Item> {
        val s = prefs.getString("layout2", null) ?: DEFAULT_LAYOUT
        val out = ArrayList<Item>()
        for (part in s.split(";")) {
            val a = part.split(":")
            if (a.size != 3) continue
            val d = defs[a[0]] ?: continue
            var cw = a[1].toIntOrNull() ?: continue
            var ch = a[2].toIntOrNull() ?: continue
            if (d.sizes.none { it.first == cw && it.second == ch }) {
                cw = d.sizes[0].first
                ch = d.sizes[0].second
            }
            out.add(Item(a[0], cw, ch))
        }
        if (out.isEmpty()) {
            for (part in DEFAULT_LAYOUT.split(";")) {
                val a = part.split(":")
                out.add(Item(a[0], a[1].toInt(), a[2].toInt()))
            }
        }
        return out
    }

    private fun save() {
        prefs.edit().putString("layout2", items.joinToString(";") { "${it.id}:${it.cw}:${it.ch}" }).apply()
    }

    // ---------- music ----------

    private fun updateMusic() {
        val t = musicTitle ?: return
        val a = musicArtist ?: return
        if (!hasListenerAccess()) {
            t.text = "در حال پخش"
            a.text = "برای نام آهنگ اینجا بزن"
            return
        }
        val c = try {
            getSystemService(MediaSessionManager::class.java)
                .getActiveSessions(ComponentName(this, MediaListenerService::class.java))
                .firstOrNull()
        } catch (e: Exception) { null }
        if (c == null) {
            t.text = "پخش نمی‌شود"
            a.text = ""
            playIcon?.ic = Ic.PLAY
            playIcon?.invalidate()
            musicArt?.setImageDrawable(null)
            musicBar?.value = 0f
            musicBar?.invalidate()
            return
        }
        val md = c.metadata
        t.text = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "—"
        a.text = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: ""
        val bmp = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
        musicArt?.setImageBitmap(bmp)
        val st = c.playbackState
        val playing = st?.state == PlaybackState.STATE_PLAYING
        playIcon?.ic = if (playing) Ic.PAUSE else Ic.PLAY
        playIcon?.invalidate()
        val dur = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        if (st != null && dur > 0) {
            var pos = st.position
            if (playing) pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
            musicBar?.value = (pos.toFloat() / dur).coerceIn(0f, 1f)
        } else {
            musicBar?.value = 0f
        }
        musicBar?.invalidate()
    }

    private fun musicCard(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = glass(30)
        box.setPadding(dp(12), dp(12), dp(12), dp(8))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL

        val art = ImageView(this)
        art.scaleType = ImageView.ScaleType.CENTER_CROP
        art.background = glass(10)
        art.clipToOutline = true
        art.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(10).toFloat())
            }
        }
        top.addView(art, LinearLayout.LayoutParams(dp(44), dp(44)))

        val title = TextView(this)
        title.setTextColor(Color.WHITE)
        title.textSize = 14f
        title.setTypeface(title.typeface, Typeface.BOLD)
        title.maxLines = 1
        title.ellipsize = TextUtils.TruncateAt.END
        val artist = TextView(this)
        artist.setTextColor(0xCCFFFFFF.toInt())
        artist.textSize = 11f
        artist.maxLines = 2
        artist.ellipsize = TextUtils.TruncateAt.END
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(title)
        col.addView(artist)
        col.setOnClickListener {
            if (!hasListenerAccess()) go(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        val colLp = LinearLayout.LayoutParams(0, WC, 1f)
        colLp.leftMargin = dp(8)
        top.addView(col, colLp)
        box.addView(top, LinearLayout.LayoutParams(MP, 0, 1f))

        val bar = ThinBar(this)
        val barLp = LinearLayout.LayoutParams(MP, dp(4))
        barLp.topMargin = dp(6)
        barLp.bottomMargin = dp(2)
        box.addView(bar, barLp)

        val controls = LinearLayout(this)
        controls.orientation = LinearLayout.HORIZONTAL
        controls.gravity = Gravity.CENTER
        fun mk(ic: Ic, code: Int): IconView {
            val iv = IconView(this, ic)
            iv.frac = 0.45f
            iv.setOnClickListener { haptic(iv); key(code) }
            controls.addView(iv, LinearLayout.LayoutParams(0, dp(40), 1f))
            return iv
        }
        mk(Ic.PREV, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        val play = mk(Ic.PLAY, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
        mk(Ic.NEXT, KeyEvent.KEYCODE_MEDIA_NEXT)
        box.addView(controls, LinearLayout.LayoutParams(MP, WC))

        musicTitle = title
        musicArtist = artist
        musicArt = art
        musicBar = bar
        playIcon = play
        return box
    }

    // ---------- item builders ----------

    private val DARK = 0x1C1C1E
    private val RED = 0xFF453A
    private val SKY = 0x0A84FF
    private val GREEN = 0x30D158

    private fun rr(item: Item) = if (item.ch >= 2) 38 else 100

    private fun single(item: Item, ic: Ic, i: Intent, base: Int?, on: Boolean = false, color: Int = 0): View {
        val t = tile(ic, rr(item), false, base) { go(i) }
        if (on) setOn(t, true, color)
        return t
    }

    private fun quickShare() {
        val i = Intent()
        i.component = ComponentName("com.google.android.gms", "com.google.android.gms.nearby.sharing.ReceiveSurfaceActivity")
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startActivity(i)
            hidePanel()
        } catch (e: Exception) {
            toast("Quick Share روی این گوشی پیدا نشد")
        }
    }

    private fun buildConnect(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER
        box.background = glass(34)
        box.setPadding(dp(8), dp(8), dp(8), dp(8))
        val m = dp(4)
        val circ = ((2 * cellPx + dp(6)) - 2 * dp(8) - 4 * m) / 2
        fun cp(): LinearLayout.LayoutParams {
            val p = LinearLayout.LayoutParams(circ, circ)
            p.setMargins(m, m, m, m)
            return p
        }

        val air = tile(Ic.AIRPLANE, 0, true, DARK) { go(Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)) }
        if (airplaneOn()) setOn(air, true, ORANGE)
        val qs = tile(Ic.AIRDROP, 0, true, DARK) { quickShare() }
        setOn(qs, true, BLUE)
        val wifi = tile(Ic.WIFI, 0, true, DARK) { go(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)) }
        if (wifiOn()) setOn(wifi, true, BLUE)

        // small 2x2 cluster: cellular data, bluetooth, hotspot, NFC
        val cluster = FrameLayout(this)
        cluster.background = glass(0, true, null, DARK)
        val inner = LinearLayout(this)
        inner.orientation = LinearLayout.VERTICAL
        inner.gravity = Gravity.CENTER
        val mini = (circ * 0.30f).toInt()
        fun mp(): LinearLayout.LayoutParams {
            val p = LinearLayout.LayoutParams(mini, mini)
            p.setMargins(dp(2), dp(2), dp(2), dp(2))
            return p
        }
        fun miniTile(ic: Ic, i: Intent, on: Boolean): FrameLayout {
            val t = tile(ic, 0, true, DARK) { go(i) }
            (t.getChildAt(0) as IconView).frac = 0.6f
            if (on) setOn(t, true, BLUE)
            return t
        }
        val rA = LinearLayout(this)
        rA.orientation = LinearLayout.HORIZONTAL
        rA.gravity = Gravity.CENTER
        val rB = LinearLayout(this)
        rB.orientation = LinearLayout.HORIZONTAL
        rB.gravity = Gravity.CENTER
        rA.addView(miniTile(Ic.DATA, Intent(Settings.ACTION_DATA_ROAMING_SETTINGS), false), mp())
        rA.addView(miniTile(Ic.BT, Intent(Settings.ACTION_BLUETOOTH_SETTINGS), btOn()), mp())
        rB.addView(miniTile(Ic.HOTSPOT, Intent("android.settings.TETHER_SETTINGS"), false), mp())
        rB.addView(miniTile(Ic.NFC, Intent(Settings.ACTION_NFC_SETTINGS), false), mp())
        inner.addView(rA)
        inner.addView(rB)
        cluster.addView(inner, FrameLayout.LayoutParams(MP, MP))

        val row1 = LinearLayout(this)
        row1.orientation = LinearLayout.HORIZONTAL
        row1.gravity = Gravity.CENTER
        row1.addView(air, cp())
        row1.addView(qs, cp())
        val row2 = LinearLayout(this)
        row2.orientation = LinearLayout.HORIZONTAL
        row2.gravity = Gravity.CENTER
        row2.addView(wifi, cp())
        row2.addView(cluster, cp())
        box.addView(row1, LinearLayout.LayoutParams(MP, 0, 1f))
        box.addView(row2, LinearLayout.LayoutParams(MP, 0, 1f))
        return box
    }

    private fun rotateTile(item: Item): View {
        val red = 0xFFFF453A.toInt()
        val t = tile(Ic.ROTATE, rr(item), false, DARK) { f ->
            if (!Settings.System.canWrite(this)) {
                go(writeSettingsIntent())
            } else {
                val locked = rotationLocked()
                Settings.System.putInt(contentResolver, Settings.System.ACCELEROMETER_ROTATION, if (locked) 1 else 0)
                setOn(f, !locked, Color.WHITE, red)
            }
        }
        if (rotationLocked()) setOn(t, true, Color.WHITE, red)
        return t
    }

    private fun toggleDnd(): Boolean? {
        if (!nm.isNotificationPolicyAccessGranted) {
            go(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            return null
        }
        val on = dndOn()
        nm.setInterruptionFilter(
            if (on) NotificationManager.INTERRUPTION_FILTER_ALL
            else NotificationManager.INTERRUPTION_FILTER_PRIORITY
        )
        return !on
    }

    private fun dndPill(): View {
        val box = FrameLayout(this)
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(dp(8), dp(8), dp(12), dp(8))
        val d = cellPx - dp(16)
        val moon = FrameLayout(this)
        moon.background = glass(0, true)
        val iv = IconView(this, Ic.MOON)
        iv.frac = 0.5f
        moon.addView(iv, FrameLayout.LayoutParams(MP, MP))
        row.addView(moon, LinearLayout.LayoutParams(d, d))
        val tv = TextView(this)
        tv.text = "مزاحم نشوید"
        tv.setTextColor(Color.WHITE)
        tv.textSize = 12f
        tv.maxLines = 1
        tv.ellipsize = TextUtils.TruncateAt.END
        tv.setPadding(dp(8), 0, 0, 0)
        row.addView(tv, LinearLayout.LayoutParams(0, WC, 1f))
        box.addView(row, FrameLayout.LayoutParams(MP, MP))
        fun paint(on: Boolean) {
            box.background = if (on) glass(100, false, PURPLE) else glass(100)
        }
        paint(dndOn())
        box.setOnClickListener {
            haptic(box)
            val r = toggleDnd()
            if (r != null) paint(r)
        }
        pressFx(box)
        return box
    }

    private fun dndTile(item: Item): View {
        if (item.cw >= 2 && item.ch == 1) return dndPill()
        val t = tile(Ic.MOON, rr(item), false, DARK) { f ->
            val r = toggleDnd()
            if (r != null) setOn(f, r, PURPLE)
        }
        if (dndOn()) setOn(t, true, PURPLE)
        return t
    }

    private fun toggleTorch() {
        val id = torchId ?: return
        try {
            if (torchOn) {
                cam.setTorchMode(id, false)
            } else if (Build.VERSION.SDK_INT >= 33 && torchMax > 1 && torchLevel > 0) {
                cam.turnOnTorchWithStrengthLevel(id, torchLevel)
            } else {
                cam.setTorchMode(id, true)
            }
        } catch (_: Exception) {}
    }

    private fun cycleTorch() {
        val id = torchId ?: return
        if (Build.VERSION.SDK_INT < 33 || torchMax <= 1) {
            toast("روشنایی چراغ قوه روی این گوشی قابل تنظیم نیست")
            return
        }
        torchStep = torchStep % 3 + 1
        torchLevel = maxOf(1, torchMax * torchStep / 3)
        try {
            cam.turnOnTorchWithStrengthLevel(id, torchLevel)
            toast("چراغ قوه ${torchStep * 100 / 3}٪")
        } catch (_: Exception) {}
    }

    private fun torchBuild(item: Item): View {
        val t = tile(Ic.TORCH, rr(item), false, DARK) { toggleTorch() }
        t.setOnLongClickListener { cycleTorch(); true }
        torchTile = t
        if (torchOn) setOn(t, true)
        return t
    }

    private fun brightSlider(): View {
        val cur = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
        val s = GSlider(this, Ic.SUN, cur / 255f, 0, 0xFFFFA800.toInt(), hapticOn) { v ->
            if (!Settings.System.canWrite(this)) {
                if (!askedWrite) {
                    askedWrite = true
                    go(writeSettingsIntent())
                }
            } else {
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS,
                    (v * 255).toInt().coerceIn(1, 255))
            }
        }
        s.background = glass(100)
        return s
    }

    private fun volSlider(): View {
        val maxV = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val curV = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        val s = GSlider(this, Ic.VOLUME, if (maxV > 0) curV.toFloat() / maxV else 0f,
            0, BLUE, hapticOn) { v ->
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(v * maxV), 0)
        }
        s.background = glass(100)
        return s
    }

    private fun build(item: Item): View = when (item.id) {
        "CONNECT" -> buildConnect()
        "MUSIC" -> musicCard()
        "ROTATE" -> rotateTile(item)
        "DND" -> dndTile(item)
        "BRIGHT" -> brightSlider()
        "VOL" -> volSlider()
        "WIFI" -> single(item, Ic.WIFI, Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY), DARK, wifiOn(), BLUE)
        "BT" -> single(item, Ic.BT, Intent(Settings.ACTION_BLUETOOTH_SETTINGS), DARK, btOn(), BLUE)
        "AIR" -> single(item, Ic.AIRPLANE, Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS), DARK, airplaneOn(), ORANGE)
        "DATA" -> single(item, Ic.DATA, Intent(Settings.ACTION_DATA_ROAMING_SETTINGS), DARK)
        "TORCH" -> torchBuild(item)
        "ALARM" -> single(item, Ic.ALARM, Intent(AlarmClock.ACTION_SHOW_ALARMS), DARK)
        "TIMER" -> single(item, Ic.TIMER, Intent(AlarmClock.ACTION_SHOW_TIMERS), DARK)
        "CALC" -> single(
            item, Ic.CALC,
            Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR), RED
        )
        "GEAR" -> single(item, Ic.GEAR, Intent(Settings.ACTION_SETTINGS), DARK)
        "BATT" -> single(item, Ic.BATTERY, Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS), DARK)
        "CAMERA" -> single(item, Ic.CAMERA, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), SKY)
        "QSHARE" -> tile(Ic.AIRDROP, rr(item), false, SKY) { quickShare() }
        "MIRROR" -> single(item, Ic.MIRROR, Intent(Settings.ACTION_CAST_SETTINGS), DARK)
        "QR" -> single(item, Ic.QR, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA), GREEN)
        else -> View(this)
    }

    // ---------- grid rendering + edit mode ----------

    private fun renderGrid() {
        val g = grid ?: return
        g.removeAllViews()
        torchTile = null
        musicTitle = null
        musicArtist = null
        musicArt = null
        musicBar = null
        playIcon = null
        items.forEachIndexed { idx, item ->
            val content = build(item)
            val h = FrameLayout(this)
            h.addView(content, FrameLayout.LayoutParams(MP, MP))
            val shield = View(this)
            shield.visibility = if (editMode) View.VISIBLE else View.GONE
            shield.setOnClickListener { selected = idx; refreshSelection() }
            h.addView(shield, FrameLayout.LayoutParams(MP, MP))
            g.addView(h, CCGrid.LP(item.cw, item.ch))
        }
        refreshSelection()
        updateMusic()
    }

    private fun refreshSelection() {
        val g = grid ?: return
        for (i in 0 until g.childCount) {
            val h = g.getChildAt(i)
            if (editMode && i == selected) {
                val o = GradientDrawable()
                o.setColor(0)
                o.setStroke(dp(2), Color.WHITE)
                o.cornerRadius = dp(26).toFloat()
                h.foreground = o
            } else {
                h.foreground = null
            }
        }
    }

    private fun pill(text: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = text
        t.setTextColor(Color.WHITE)
        t.textSize = 13f
        t.gravity = Gravity.CENTER
        t.background = glass(18)
        t.setPadding(dp(6), dp(10), dp(6), dp(10))
        t.setOnClickListener { haptic(t); onClick() }
        return t
    }

    private fun toggleEdit() {
        editMode = !editMode
        selected = -1
        editBtn?.ic = if (editMode) Ic.CHECK else Ic.PLUS
        editBtn?.invalidate()
        toolbar?.visibility = if (editMode) View.VISIBLE else View.GONE
        renderGrid()
    }

    private fun removeSelected() {
        if (selected < 0 || selected >= items.size) { toast("اول یه دکمه رو انتخاب کن"); return }
        items.removeAt(selected)
        selected = -1
        save()
        renderGrid()
    }

    private fun resizeSelected() {
        if (selected < 0 || selected >= items.size) { toast("اول یه دکمه رو انتخاب کن"); return }
        val it = items[selected]
        val sizes = defs[it.id]?.sizes ?: return
        val cur = sizes.indexOfFirst { s -> s.first == it.cw && s.second == it.ch }
        val nxt = sizes[(cur + 1) % sizes.size]
        it.cw = nxt.first
        it.ch = nxt.second
        save()
        renderGrid()
    }

    private fun moveSelected(delta: Int) {
        if (selected < 0 || selected >= items.size) { toast("اول یه دکمه رو انتخاب کن"); return }
        val to = selected + delta
        if (to < 0 || to >= items.size) return
        val tmp = items[selected]
        items[selected] = items[to]
        items[to] = tmp
        selected = to
        save()
        renderGrid()
    }

    private fun showPicker() {
        val root = panel as? FrameLayout ?: return
        val present = items.map { x -> x.id }.toSet()
        val avail = defs.filter { e -> e.key !in present }
        if (avail.isEmpty()) { toast("همه کنترل‌ها اضافه شدن"); return }

        val shade = FrameLayout(this)
        shade.setBackgroundColor(0x77000000)
        shade.setOnClickListener { root.removeView(shade) }

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.isClickable = true
        val bg = GradientDrawable()
        bg.setColor(0xEE1C1C1E.toInt())
        bg.cornerRadius = dp(26).toFloat()
        box.background = bg
        box.setPadding(dp(16), dp(16), dp(16), dp(16))

        val head = TextView(this)
        head.text = "یه کنترل برای اضافه کردن انتخاب کن"
        head.setTextColor(Color.WHITE)
        head.textSize = 15f
        head.setTypeface(head.typeface, Typeface.BOLD)
        box.addView(head)

        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        for ((id, d) in avail) {
            val row = TextView(this)
            row.text = d.name
            row.setTextColor(Color.WHITE)
            row.textSize = 15f
            row.setPadding(dp(8), dp(14), dp(8), dp(14))
            row.setOnClickListener {
                items.add(Item(id, d.sizes[0].first, d.sizes[0].second))
                selected = items.size - 1
                save()
                renderGrid()
                root.removeView(shade)
            }
            list.addView(row, LinearLayout.LayoutParams(MP, WC))
        }
        val sv = MaxHeightScroll(this, resources.displayMetrics.heightPixels / 2)
        sv.addView(list, ViewGroup.LayoutParams(MP, WC))
        box.addView(sv, LinearLayout.LayoutParams(MP, WC))

        shade.addView(box, FrameLayout.LayoutParams(dp(270), WC, Gravity.CENTER))
        root.addView(shade, FrameLayout.LayoutParams(MP, MP))
    }

    // ---------- panel ----------

    private fun showPanel() {
        if (panel != null) return
        askedWrite = false
        editMode = false
        selected = -1
        gA = (prefs.getInt("alpha", 40) * 255 / 100).coerceIn(0, 255)
        tintRgb = TINT_RGB.getOrElse(prefs.getInt("tint", 0)) { 0xFFFFFF }
        hapticOn = prefs.getBoolean("haptic", true)
        items = loadItems()
        cellPx = (resources.displayMetrics.widthPixels - dp(12) * 2 - dp(4) * 2 - dp(6) * 5) / 4

        val root = FrameLayout(this)
        root.setBackgroundColor(0x55000000)
        root.setOnClickListener { hidePanel() }

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.isClickable = true
        card.setPadding(dp(4), dp(4), dp(4), dp(4))

        // top bar with the edit (+) button
        val topBar = LinearLayout(this)
        topBar.orientation = LinearLayout.HORIZONTAL
        topBar.gravity = Gravity.CENTER_VERTICAL
        val eb = IconView(this, Ic.PLUS)
        eb.frac = 0.46f
        eb.background = glass(0, true)
        eb.setOnClickListener { haptic(eb); toggleEdit() }
        pressFx(eb)
        editBtn = eb
        topBar.addView(eb, lp(dp(44), dp(44)))
        card.addView(topBar, LinearLayout.LayoutParams(MP, WC))

        // grid inside a height-limited scroll view
        val g = CCGrid(this, 4, dp(6))
        grid = g
        val maxH = resources.displayMetrics.heightPixels - (statusBarH() + dp(6 + 52 + 64 + 40))
        val sv = MaxHeightScroll(this, maxH)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(g, ViewGroup.LayoutParams(MP, WC))
        card.addView(sv, LinearLayout.LayoutParams(MP, WC))

        // edit toolbar
        val tb = LinearLayout(this)
        tb.orientation = LinearLayout.HORIZONTAL
        tb.visibility = View.GONE
        tb.addView(pill("＋ افزودن") { showPicker() }, lp(0, WC, 1f))
        tb.addView(pill("حذف") { removeSelected() }, lp(0, WC, 1f))
        tb.addView(pill("اندازه") { resizeSelected() }, lp(0, WC, 1f))
        tb.addView(pill("قبلی") { moveSelected(-1) }, lp(0, WC, 1f))
        tb.addView(pill("بعدی") { moveSelected(1) }, lp(0, WC, 1f))
        toolbar = tb
        card.addView(tb, LinearLayout.LayoutParams(MP, WC))

        val cardLp = FrameLayout.LayoutParams(MP, WC)
        cardLp.setMargins(dp(12), statusBarH() + dp(6), dp(12), 0)
        root.addView(card, cardLp)

        val params = WindowManager.LayoutParams(
            MP, MP, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 31) {
            params.flags = params.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            params.blurBehindRadius = 90
        }
        wm.addView(root, params)
        panel = root

        renderGrid()

        // entrance animation: card slides in, tiles pop in one after another
        root.alpha = 0f
        card.translationY = -dp(60).toFloat()
        card.scaleX = 0.95f
        card.scaleY = 0.95f
        root.animate().alpha(1f).setDuration(220).start()
        card.animate().translationY(0f).scaleX(1f).scaleY(1f).setDuration(380)
            .setInterpolator(OvershootInterpolator(0.8f)).start()
        for (i in 0 until g.childCount) {
            val ch = g.getChildAt(i)
            ch.alpha = 0f
            ch.scaleX = 0.85f
            ch.scaleY = 0.85f
            ch.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setStartDelay(60L + i * 24L).setDuration(300)
                .setInterpolator(OvershootInterpolator(1.1f)).start()
        }

        handler.postDelayed(ticker, 1000)
    }

    private fun hidePanel() {
        val p = panel ?: return
        panel = null
        handler.removeCallbacks(ticker)
        editMode = false
        selected = -1
        grid = null
        toolbar = null
        editBtn = null
        torchTile = null
        musicTitle = null
        musicArtist = null
        musicArt = null
        musicBar = null
        playIcon = null
        p.animate().alpha(0f).setDuration(170).setInterpolator(DecelerateInterpolator()).withEndAction {
            try { wm.removeView(p) } catch (_: Exception) {}
        }.start()
    }
}
