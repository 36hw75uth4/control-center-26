package com.example.cc

import android.app.*
import android.content.ClipData
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.view.*
import android.view.animation.DecelerateInterpolator
import android.widget.*

class ControlCenterService : Service() {
    private val MP = ViewGroup.LayoutParams.MATCH_PARENT
    private val WC = ViewGroup.LayoutParams.WRAP_CONTENT
    private lateinit var wm: WindowManager
    private lateinit var cam: CameraManager
    private lateinit var audio: AudioManager
    private var trigger: View? = null
    private var panel: View? = null
    private var torchId: String? = null
    private var torchOn = false
    private var torchBtn: TextView? = null
    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(id: String, enabled: Boolean) {
            torchOn = enabled
            torchBtn?.background = glass(22, false, enabled)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        cam = getSystemService(CAMERA_SERVICE) as CameraManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        torchId = cam.cameraIdList.firstOrNull {
            cam.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
        cam.registerTorchCallback(torchCb, null)

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cc", "Control Center", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "cc")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Control Center")
            .setContentText("از گوشه بالا-راست به پایین بکش")
            .build()
        startForeground(1, n)
        addTrigger()
    }

    override fun onDestroy() {
        trigger?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        cam.unregisterTorchCallback(torchCb)
        super.onDestroy()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    /** Liquid-glass look: translucent diagonal gradient + bright hairline stroke. */
    private fun glass(r: Int, oval: Boolean = false, on: Boolean = false) = GradientDrawable(
        GradientDrawable.Orientation.TL_BR,
        if (on) intArrayOf(0xFFFFFFFF.toInt(), 0xDDFFFFFF.toInt()) else intArrayOf(0x66FFFFFF, 0x1FFFFFFF)
    ).apply {
        if (oval) shape = GradientDrawable.OVAL else cornerRadius = dp(r).toFloat()
        setStroke(dp(1), 0x77FFFFFF)
    }

    private fun addTrigger() {
        val v = View(this).apply { setBackgroundColor(0x01FFFFFF) }
        var startY = 0f
        var fired = false
        v.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { startY = e.rawY; fired = false }
                MotionEvent.ACTION_MOVE -> if (!fired && e.rawY - startY > dp(40)) { fired = true; showPanel() }
            }
            true
        }
        val lp = WindowManager.LayoutParams(
            dp(140), dp(24), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END }
        wm.addView(v, lp)
        trigger = v
    }

    private fun lp(w: Int, h: Int, wt: Float = 0f) =
        LinearLayout.LayoutParams(w, h, wt).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }

    private fun tile(emoji: String, oval: Boolean, onClick: (TextView) -> Unit) = TextView(this).apply {
        text = emoji; textSize = 24f; gravity = Gravity.CENTER
        background = glass(22, oval)
        setOnClickListener { onClick(this) }
    }

    private fun go(i: Intent) {
        try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
        hidePanel()
    }

    private fun sliderCard(emoji: String, max: Int, progress: Int, onChange: (Int) -> Unit) =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = glass(26)
            setPadding(dp(18), dp(12), dp(18), dp(12))
            addView(TextView(context).apply { text = emoji; textSize = 22f })
            addView(SeekBar(context).apply {
                this.max = max; this.progress = progress
                progressTintList = ColorStateList.valueOf(Color.WHITE)
                thumbTintList = ColorStateList.valueOf(Color.WHITE)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { if (u) onChange(p) }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }, LinearLayout.LayoutParams(0, WC, 1f).apply { leftMargin = dp(12) })
        }

    private fun showPanel() {
        if (panel != null) return
        val root = FrameLayout(this).apply {
            setBackgroundColor(0x55000000)
            setOnClickListener { hidePanel() }
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isClickable = true
            setPadding(dp(10), dp(10), dp(10), dp(10))
        }

        // Row 1: connectivity block + torch/camera
        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val conn = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = glass(30)
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        fun circ(e: String, i: Intent) = tile(e, true) { go(i) }
        val r1 = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val r2 = LinearLayout(this).apply { gravity = Gravity.CENTER }
        r1.addView(circ("📶", Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)), lp(dp(60), dp(60)))
        r1.addView(circ("🔵", Intent(Settings.ACTION_BLUETOOTH_SETTINGS)), lp(dp(60), dp(60)))
        r2.addView(circ("✈️", Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)), lp(dp(60), dp(60)))
        r2.addView(circ("📡", Intent(Settings.ACTION_DATA_ROAMING_SETTINGS)), lp(dp(60), dp(60)))
        conn.addView(r1); conn.addView(r2)
        row1.addView(conn, lp(0, dp(150), 1f))

        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        torchBtn = tile("🔦", false) {
            try { torchId?.let { id -> cam.setTorchMode(id, !torchOn) } } catch (_: Exception) {}
        }.also { it.background = glass(22, false, torchOn) }
        right.addView(torchBtn, lp(MP, 0, 1f))
        right.addView(tile("📷", false) { go(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)) }, lp(MP, 0, 1f))
        row1.addView(right, lp(0, dp(150), 1f))
        card.addView(row1)

        // Brightness
        val curB = Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128)
        card.addView(sliderCard("☀️", 255, curB) { p ->
            if (!Settings.System.canWrite(this)) {
                go(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
            } else {
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE,
                    Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS, p.coerceAtLeast(1))
            }
        }, lp(MP, WC))

        // Volume
        card.addView(sliderCard("🔊", audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
            audio.getStreamVolume(AudioManager.STREAM_MUSIC)) { p ->
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0)
        }, lp(MP, WC))

        // Bottom shortcuts
        val row4 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row4.addView(tile("⏰", false) { go(Intent(AlarmClock.ACTION_SHOW_ALARMS)) }, lp(0, dp(76), 1f))
        row4.addView(tile("⚙️", false) { go(Intent(Settings.ACTION_SETTINGS)) }, lp(0, dp(76), 1f))
        row4.addView(tile("🔔", false) { go(Intent(Settings.ACTION_SOUND_SETTINGS)) }, lp(0, dp(76), 1f))
        row4.addView(tile("🔋", false) { go(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS)) }, lp(0, dp(76), 1f))
        card.addView(row4)

        root.addView(card, FrameLayout.LayoutParams(MP, WC).apply {
            setMargins(dp(14), dp(56), dp(14), 0)
        })

        val params = WindowManager.LayoutParams(
            MP, MP, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 31) { // real background blur (Android 12+)
            params.flags = params.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            params.blurBehindRadius = 90
        }
        wm.addView(root, params)
        panel = root

        root.alpha = 0f
        card.translationY = -dp(80).toFloat()
        root.animate().alpha(1f).setDuration(220).start()
        card.animate().translationY(0f).setDuration(300).setInterpolator(DecelerateInterpolator()).start()
    }

    private fun hidePanel() {
        val p = panel ?: return
        panel = null
        p.animate().alpha(0f).setDuration(160).withEndAction {
            try { wm.removeView(p) } catch (_: Exception) {}
        }.start()
    }
}
