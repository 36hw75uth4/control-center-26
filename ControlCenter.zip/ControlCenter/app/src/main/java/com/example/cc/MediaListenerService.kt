package com.example.cc

import android.service.notification.NotificationListenerService

/** Empty on purpose: having notification access lets us read the active media session (song title). */
class MediaListenerService : NotificationListenerService()
